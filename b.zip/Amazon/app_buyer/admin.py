from django.contrib import admin

from app_buyer.models import User,Cart

# Register your models here.
admin.site.register(User)
admin.site.register(Cart)
