from django.contrib import admin

from app_seller.models import Product, Userseller

# Register your models here.
admin.site.register(Userseller)
admin.site.register(Product)
